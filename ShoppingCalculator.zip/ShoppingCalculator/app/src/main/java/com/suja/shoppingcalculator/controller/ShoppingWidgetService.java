package com.suja.shoppingcalculator.controller;

import android.content.Intent;
import android.widget.RemoteViewsService;



/**
 * Created by Suja Manu on 12/4/2018.
 */

public class ShoppingWidgetService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        GridRemoteViewsFactory gridRemoteViewsFactory=new GridRemoteViewsFactory(this.getApplicationContext(),intent);
        gridRemoteViewsFactory.onDataSetChanged();
        return gridRemoteViewsFactory;
    }
}
