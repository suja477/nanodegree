package com.suja.shoppingcalculator.model;

import java.util.Date;

/**
 * Created by Suja Manu on 11/29/2018.
 */

public class History {
    String date;
    Float bill;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Float getBill() {
        return bill;
    }

    public void setBill(Float bill) {
        this.bill = bill;
    }
}
