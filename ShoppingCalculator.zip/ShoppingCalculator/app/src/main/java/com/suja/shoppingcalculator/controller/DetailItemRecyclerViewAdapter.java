package com.suja.shoppingcalculator.controller;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.suja.shoppingcalculator.R;
import com.suja.shoppingcalculator.model.ShoppingItem;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

/**
 * Created by Suja Manu on 11/27/2018.
 */

public class DetailItemRecyclerViewAdapter
        extends RecyclerView.Adapter<DetailItemRecyclerViewAdapter.ItemRecyclerViewHolder> {

    private final Context mContext;
    private static ShoppingItem shoppingItem;
    String uri;
    private List<ShoppingItem> mShoppintItems;
    private static String TAG = "com.suja.shoppingCalculator";
    public float price;
    public int quantity;


    public TextView total;

    public DetailItemRecyclerViewAdapter(Context context, ArrayList<ShoppingItem> selectedShoppingItem, TextView sumValue) {
        this.mContext = context;
    }


    public DetailItemRecyclerViewAdapter(Context context,ArrayList<ShoppingItem> mShoppintItems) {
        this.mContext = context;
        this.mShoppintItems=mShoppintItems;
    }


    public DetailItemRecyclerViewAdapter(Context context, TextView textView) {
        this.mContext = context;
        this.total = textView;
    }

    @Override
    public ItemRecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.detail_item_list, parent, false);
        return new ItemRecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ItemRecyclerViewHolder holder, final int position) {
        holder.itemName.setText((mShoppintItems.get(position).getName()));
        if((mShoppintItems.get(position).getPrice())!=null&&!(mShoppintItems.get(position).getPrice()).isEmpty())
        holder.itemPrice.setText((mShoppintItems.get(position).getPrice()));
        if((mShoppintItems.get(position).getSum())!=null&&!(mShoppintItems.get(position).getSum()).isEmpty())
            holder.itemSum.setText((mShoppintItems.get(position).getSum()));
        if((mShoppintItems.get(position).getWeight())!=null&&!(mShoppintItems.get(position).getWeight()).isEmpty())
            holder.itemQty.setText((mShoppintItems.get(position).getWeight()));



    }

    @Override
    public int getItemCount() {
        if (mShoppintItems != null)
            return mShoppintItems.size();
        else return 0;
    }
    @Override
    public int getItemViewType(final int position) {
        return position;
    }
    public void setItems(List<ShoppingItem> items) {
        mShoppintItems = items;
        notifyDataSetChanged();
    }

    public class ItemRecyclerViewHolder extends RecyclerView.ViewHolder {
        TextView itemName;
        TextView itemPrice;
        TextView itemQty;
        TextView itemSum;
        Boolean noPriceEntered=true;

        // ImageView itemImage;
        public ItemRecyclerViewHolder(View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.item_detail_name);
            itemPrice = itemView.findViewById(R.id.item_detail_price);
            itemQty = itemView.findViewById(R.id.item_detail_weight);
            itemSum = itemView.findViewById(R.id.item_detail_sum);
            //itemImage=itemView.findViewById(R.id.item_image);
            itemPrice.addTextChangedListener(new TextWatcher() {
                @Override
                public void onTextChanged(CharSequence s, int start,
                                          int before, int count) {

                }

                @Override
                public void beforeTextChanged(CharSequence s, int start,
                                              int count, int after) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    //setting data to array, when changed
                    mShoppintItems.get(getItemViewType()).setPrice(s.toString());
                    if(s.toString()!=null&& s.toString().isEmpty()){
                        noPriceEntered=true;
                        Log.i("price is empty",noPriceEntered.toString());
                    }else {
                        noPriceEntered=false;
                        Log.i("price is entered",s.toString());
                    }
                }
            });
            itemQty.addTextChangedListener(new TextWatcher() {
                @Override
                public void onTextChanged(CharSequence s, int start,
                                          int before, int count) {
                    //setting data to array, when changed
                    mShoppintItems.get(getItemViewType()).setWeight(s.toString());
                    try {
                        if(!noPriceEntered)//if price entered
                        { Float sum = Float.parseFloat(mShoppintItems.get(getItemViewType()).getPrice()) *
                                Float.parseFloat(mShoppintItems.get(getItemViewType()).getWeight());
                            mShoppintItems.get(getItemViewType()).setSum(sum.toString());
                            itemSum.setText(sum.toString());
                            Log.i("price enterd and sum",sum.toString());}
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void beforeTextChanged(CharSequence s, int start,
                                              int count, int after) {

                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });
            itemSum.addTextChangedListener(new TextWatcher() {
                @Override
                public void onTextChanged(CharSequence s, int start,
                                          int before, int count) {

                }

                @Override
                public void beforeTextChanged(CharSequence s, int start,
                                              int count, int after) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    //setting data to array, when changed
                    Log.i("sum found",s.toString());
                    mShoppintItems.get(getItemViewType()).setSum(s.toString());
                    try {

                        if(noPriceEntered)//if no price entered
                        {
                                Float perkg = Float.parseFloat(mShoppintItems.get(getItemViewType()).getSum()) /
                                        Float.parseFloat(mShoppintItems.get(getItemViewType()).getWeight());
                                mShoppintItems.get(getItemViewType()).setPrice(perkg.toString());
                                Log.i("perkg found", perkg.toString());
                                Log.i("sum found", s.toString());

                                // itemPrice.setText(perkg.toString());
                                // noPriceEntered=false;

                        }}
                     catch (Exception e) {
                        e.printStackTrace();
                         mShoppintItems.get(getItemViewType()).setPrice("0");
                         mShoppintItems.get(getItemViewType()).setSum("0");


                     }}

            });
        }

    }
}
