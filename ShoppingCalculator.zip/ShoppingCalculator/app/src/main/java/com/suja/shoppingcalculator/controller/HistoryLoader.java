package com.suja.shoppingcalculator.controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import com.suja.shoppingcalculator.model.History;
import com.suja.shoppingcalculator.model.HistoryContract;
import com.suja.shoppingcalculator.model.ShoppingItem;
import com.suja.shoppingcalculator.model.ShoppingItemContract;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by Suja Manu on 11/29/2018.
 */

public class HistoryLoader extends AsyncTask {
    private final Context context;

    public HistoryLoader(Context context, AsyncTaskCompleteListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public AsyncTaskCompleteListener listener;

    public HistoryLoader(Context context) {
        this.context = context;
    }

    @Override
    protected Object doInBackground(Object[] objects) {
        return null;
    }

    public ArrayList<History> selectAllHistory() {
        Uri uri = HistoryContract.HistoryEntry.CONTENT_URI;
        Cursor cursor = context.getContentResolver().query(uri, null, null,
                null, null);
        ArrayList<History> histories=new ArrayList<History>();
        for (int i = 0; i < cursor.getCount(); i++) {
            Log.i("cursor values",cursor.getColumnIndex(HistoryContract.HistoryEntry.COLUMN_DATE)+"");
            int dateIndex = cursor.getColumnIndex(HistoryContract.HistoryEntry.COLUMN_DATE);
            int billIndex = cursor.getColumnIndex(HistoryContract.HistoryEntry.COLUMN_BILL);
          cursor.moveToPosition(i); // get to the right location in the cursor
            History item = new History();
            Log.i("curosr check",cursor.getString(dateIndex));

            if(cursor.getString(dateIndex)!=null)item.setDate(cursor.getString(dateIndex));
            if(0!=cursor.getLong(billIndex))item.setBill((float) cursor.getLong(billIndex));

            histories.add(item);
        }
        return histories;
    }


    public void insertHistory(History myItem) {
        Log.i("inside insert", myItem.getDate().toString() +myItem.getBill());
        // Create new empty ContentValues object
        ContentValues contentValues = new ContentValues();


        // Put the task description and selected mPriority into the ContentValues
        contentValues.put(HistoryContract.HistoryEntry.COLUMN_DATE, String.valueOf(myItem.getDate()));
        contentValues.put(HistoryContract.HistoryEntry.COLUMN_BILL, myItem.getBill());

        // Insert the content values via a ContentResolver

        Uri uri = context.getContentResolver().insert(HistoryContract.HistoryEntry.CONTENT_URI, contentValues);


    }
}
