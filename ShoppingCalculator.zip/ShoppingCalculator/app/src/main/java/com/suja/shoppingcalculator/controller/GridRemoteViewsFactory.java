package com.suja.shoppingcalculator.controller;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.suja.shoppingcalculator.R;
import com.suja.shoppingcalculator.model.ShoppingItem;

/**
 * Created by Suja Manu on 12/4/2018.
 */

class GridRemoteViewsFactory implements RemoteViewsService.RemoteViewsFactory {
    Context mContext;
    ShoppingItem[] shoppingList;
    private int appWidgetId;
    public GridRemoteViewsFactory(Context applicationContext) {
        mContext = applicationContext;

    }
    public GridRemoteViewsFactory(Context context, Intent intent)
    {
        this.mContext = context;
        appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);
        Log.d("AppWidgetId", String.valueOf(appWidgetId));
     //   dbhelper = new DBHelper(this.context);
    }

    @Override
    public void onCreate() {
        shoppingList=Utility.loadJSONFromAsset(mContext);
    }

    @Override
    public void onDataSetChanged() {

        shoppingList=Utility.loadJSONFromAsset(mContext);
    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        if(shoppingList!=null)
        return shoppingList.length;
        else return 0;
    }

    @Override
    public RemoteViews getViewAt(int i) {
        RemoteViews views = new RemoteViews(mContext.getPackageName(), R.layout.widget_list_row);
        views.setTextViewText(R.id.widget_row_name,shoppingList[i].getName());
        ShoppingItem item=new ShoppingItemLoader(mContext)
                .selectItemsLatestPrice(shoppingList[i].getName());
        views.setTextViewText(R.id.widget_row_price,item.getPrice());

        return views;

    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }
}
