package com.suja.shoppingcalculator.model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.suja.shoppingcalculator.model.ShoppingItemContract;

/**
 * Created by Suja Manu on 11/26/2018.
 */

public class DatabaseHelperHistory extends SQLiteOpenHelper {

    // The database name
    private static final String DATABASE_NAME = "History.db";

    // If you change the database schema, you must increment the database version
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelperHistory(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // Create a table to hold waitlist data
        final String SQL_CREATE_ITEM_TABLE = "CREATE TABLE " + HistoryContract.HistoryEntry.TABLE_NAME + " (" +
                HistoryContract.HistoryEntry.COLUMN_DATE + " TEXT PRIMARY KEY ," +
                HistoryContract.HistoryEntry.COLUMN_BILL + " NUMBER  NULL " +
                "); ";

        sqLiteDatabase.execSQL(SQL_CREATE_ITEM_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + HistoryContract.HistoryEntry.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }
}
