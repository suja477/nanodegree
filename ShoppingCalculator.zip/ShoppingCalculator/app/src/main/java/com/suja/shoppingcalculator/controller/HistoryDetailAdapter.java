package com.suja.shoppingcalculator.controller;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.suja.shoppingcalculator.R;
import com.suja.shoppingcalculator.model.History;
import com.suja.shoppingcalculator.model.ShoppingItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Suja Manu on 11/29/2018.
 */

public class HistoryDetailAdapter extends ArrayAdapter<ShoppingItem> {
    int groupid;
    Context context;
    ArrayList<ShoppingItem> list;
    LayoutInflater inflater;
    String uri;
    public HistoryDetailAdapter(Context context, int groupid, int id, ArrayList<ShoppingItem>list){
        super(context,id,list);
        this.list=list;
        inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.groupid=groupid;
        this.context=context;
    }
    public View getView(int position, View convertView, ViewGroup parent ){
        View itemView=inflater.inflate(groupid,parent,false);
        ImageView imageView=itemView.findViewById(R.id.old_image);
        if((list.get(position).getUrl())!="")
            uri = "@drawable/"+ list.get(position).getUrl();
        // where myresource (without the extension) is the file

        int imageResource = context.getResources()
                .getIdentifier(uri, null, context.getPackageName());
        if(imageResource!=0)
            Picasso.with(context)
                    .load(imageResource)
                    .resize(100, 100).centerCrop()
                    .error(R.drawable.ic_launcher_background)
                    .into(imageView);
        TextView oldName=(TextView) itemView.findViewById(R.id.old_name);
        TextView oldprice=(TextView) itemView.findViewById(R.id.old_price);
        TextView oldweight=(TextView) itemView.findViewById(R.id.old_weight);
        TextView oldsum=(TextView) itemView.findViewById(R.id.old_per_kg);
        oldName.setText(list.get(position).getName());
        oldprice.setText(list.get(position).getPrice());
        oldweight.setText(list.get(position).getWeight());
        try {
            Float sum=0F;
             sum = Float.parseFloat(list.get(position).getPrice().toString())
                    * Float.parseFloat(list.get(position).getWeight().toString());
            oldsum.setText(String.valueOf(sum));
        }
        catch (Exception e){
            e.printStackTrace();
        }



        Log.i("old price data",oldName.getText().toString()
                +oldprice.getText().toString()+oldweight.getText().toString());

        return itemView;
    }

    public void setItems(ArrayList<ShoppingItem> items) {
        list = items;
        notifyDataSetChanged();
    }

    public View getDropDownView(int position, View convertView, ViewGroup
            parent){
        return getView(position,convertView,parent);

    }
}
