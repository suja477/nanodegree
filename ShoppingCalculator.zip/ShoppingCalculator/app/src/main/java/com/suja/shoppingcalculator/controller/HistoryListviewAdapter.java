package com.suja.shoppingcalculator.controller;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.suja.shoppingcalculator.R;
import com.suja.shoppingcalculator.model.History;
import com.suja.shoppingcalculator.model.ShoppingItem;

import java.util.ArrayList;

/**
 * Created by Suja Manu on 11/29/2018.
 */

public class HistoryListviewAdapter extends ArrayAdapter<History> {
    int groupid;
    Activity context;
    ArrayList<History> list;
    LayoutInflater inflater;
    String uri;
    public HistoryListviewAdapter(Activity context, int groupid, int id, ArrayList<History>
            list){
        super(context,id,list);
        this.list=list;
        inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.groupid=groupid;
        this.context=context;
    }
    public View getView(int position, View convertView, ViewGroup parent ){
        View itemView=inflater.inflate(groupid,parent,false);
        TextView textView=(TextView) itemView.findViewById(R.id.date_history);
        textView.setText(list.get(position).getDate());
        TextView billview=itemView.findViewById(R.id.bill_history);
        try {

            billview.setText(list.get(position).getBill().toString());
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return itemView;
    }

    public View getDropDownView(int position, View convertView, ViewGroup
            parent){
        return getView(position,convertView,parent);

    }
}
