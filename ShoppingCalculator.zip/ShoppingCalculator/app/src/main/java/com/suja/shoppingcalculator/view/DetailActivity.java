package com.suja.shoppingcalculator.view;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.suja.shoppingcalculator.R;
import com.suja.shoppingcalculator.controller.DetailItemRecyclerViewAdapter;
import com.suja.shoppingcalculator.controller.HistoryDetailAdapter;
import com.suja.shoppingcalculator.controller.HistoryListviewAdapter;
import com.suja.shoppingcalculator.controller.HistoryLoader;
import com.suja.shoppingcalculator.controller.ShoppingItemLoader;
import com.suja.shoppingcalculator.controller.SpinnerAdapter;
import com.suja.shoppingcalculator.controller.Utility;
import com.suja.shoppingcalculator.model.History;
import com.suja.shoppingcalculator.model.ShoppingItem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class DetailActivity extends AppCompatActivity implements MyDialogFragment.YesNoListener {
    RecyclerView mRecyclerView;
    DetailItemRecyclerViewAdapter detailItemRecyclerViewAdapter;
    public ArrayList<ShoppingItem> arrayList;
    ArrayList<ShoppingItem> selectedShoppingItem;
    public SpinnerAdapter adapter;
    public TextView sumValue;
    public ArrayList<ShoppingItem> oldShoppingList = new ArrayList<ShoppingItem>();
    public HistoryDetailAdapter historyDetailAdapter;
    public static final int PICK_VEG = 1;
    public static boolean spinnerDialog = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra("selected");
        selectedShoppingItem = bundle.getParcelableArrayList("selectedlist");
        mRecyclerView = findViewById(R.id.item_recycler_view_detail);

        //sumValue=findViewById(R.id.total_sum_display);
        detailItemRecyclerViewAdapter = new DetailItemRecyclerViewAdapter(this, selectedShoppingItem);
        mRecyclerView.setAdapter(detailItemRecyclerViewAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);

        mRecyclerView.setLayoutManager(layoutManager);

        // selectedShoppingItem =new ArrayList<ShoppingItem>();
        detailItemRecyclerViewAdapter.setItems(selectedShoppingItem);
        mRecyclerView.setAdapter(detailItemRecyclerViewAdapter);

        ShoppingItem[] list = Utility.loadJSONFromAsset(this);//load full list from asset

        arrayList = new ArrayList<ShoppingItem>(Arrays.asList(list));
        adapter = new SpinnerAdapter(this,
                R.layout.spinner_layout, R.id.spinner_txt, arrayList);//not needed


    }

    public void onClick(View w) {

        new MyDialogFragment(arrayList)
                .show(getFragmentManager(), "tag");
        spinnerDialog = true;



       /* new AlertDialog.Builder(this)
                .setTitle("Add vegetable")
                .setAdapter(adapter, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int position) {

                        ShoppingItem selectedItem = arrayList.get(position);
                        Log.i("selected spinner item", arrayList.get(position).getName());
                        boolean present = false;
                        for (ShoppingItem shoppingItem : selectedShoppingItem) {
                            if (selectedItem.getName().equalsIgnoreCase(shoppingItem.getName()))
                                present = true;
                        }

                        if (!present)//add item to selected list
                            selectedShoppingItem.add(arrayList.get(position));
                        detailItemRecyclerViewAdapter.setItems(selectedShoppingItem);


                        dialog.dismiss();
                    }
                }).setNeutralButton("Cancel", new DialogInterface.OnClickListener() { // define the 'Cancel' button
            public void onClick(DialogInterface dialog, int which) {
                //Either of the following two lines should work.
                dialog.cancel();
                //dialog.dismiss();
            }
        }).create().show();*/
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //insert shopping item details for price
        for (ShoppingItem item : selectedShoppingItem) {
            Date date = java.util.Calendar.getInstance().getTime();
            item.setDate(date.toString());
            Log.i("inserting ", item.getName() + item.getPrice() + item.getWeight());
            new ShoppingItemLoader(this).insertShoppingItem(item);
        }

        //insert history
        Date date = java.util.Calendar.getInstance().getTime();
        Log.i("date", date.toString());
        History history = new History();
        history.setDate(date.toString());
        TextView bill = findViewById(R.id.total_value);

        //insert history only if bill has a value
        if (bill.getText() != null) if (bill.getText() != "") if (bill.getText() != "0") {
            history.setBill(Float.parseFloat(bill.getText().toString()));

            new HistoryLoader(this).insertHistory(history);
            Log.i("insert history", bill.getText().toString());
        }
    }


    public void viewHistory(View view) {
        final ArrayList<History> histories = new HistoryLoader(this).selectAllHistory();
        final HistoryListviewAdapter historyadapter = new HistoryListviewAdapter(this,
                R.layout.history_list, R.id.date_history, histories);
        LayoutInflater inflater = getLayoutInflater();
        View header = inflater.inflate(R.layout.header_bill_history, null);

        new AlertDialog.Builder(this)
                .setTitle(R.string.title_view_history).setCustomTitle(header)
                .setAdapter(historyadapter, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int position) {

                        History history = histories.get(position);
                        String date = histories.get(position).getDate().toString();
                        Log.i("selected spinner item", date);
                        oldShoppingList = new ShoppingItemLoader(DetailActivity.this)
                                .selectAllItemsWithDate(date);
                        for (ShoppingItem item : oldShoppingList)
                            Log.i("oldshopping", item.getName());
                        //historyDetailAdapter.setItems(oldShoppingList);
                        historyDetailAdapter =
                                new HistoryDetailAdapter(DetailActivity.this,
                                        R.layout.history_detail, R.id.old_name, oldShoppingList);
                        LayoutInflater inflater = getLayoutInflater();
                        View header = inflater.inflate(R.layout.header_detailed_bill, null);

                        new AlertDialog.Builder(DetailActivity.this)
                                .setTitle(R.string.title_view_bill_details).setCustomTitle(header)
                                .setAdapter(historyDetailAdapter, new DialogInterface.OnClickListener() {

                                    @Override
                                    public void onClick(DialogInterface dialog, int position) {

                                        dialog.dismiss();
                                    }
                                }).setNeutralButton("Cancel", new DialogInterface.OnClickListener() { // define the 'Cancel' button
                            public void onClick(DialogInterface dialog, int which) {
                                //Either of the following two lines should work.
                                dialog.cancel();
                                //dialog.dismiss();
                            }
                        }).create().show();
                        dialog.dismiss();
                    }
                }).setNeutralButton("Cancel", new DialogInterface.OnClickListener() { // define the 'Cancel' button
            public void onClick(DialogInterface dialog, int which) {
                //Either of the following two lines should work.
                dialog.cancel();
                //dialog.dismiss();
            }
        }).create().show();
    }


    public void getTotalBill(View view) {


        Float sum = 0F;
        for (int i = 0; i < selectedShoppingItem.size(); i++) {
            try {
                sum = sum + Float.parseFloat(selectedShoppingItem.get(i).getSum());
            }catch (Exception e){
                e.printStackTrace();

            }
        }

       // detailItemRecyclerViewAdapter.setItems(selectedShoppingItem);

        TextView sumText = findViewById(R.id.total_value);
        sumText.setText(String.valueOf(sum));
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);


    }

    @Override
    public void onClickDialogSpinner(int position) {
        ShoppingItem selectedItem = arrayList.get(position);
        Log.i("selected spinner item", arrayList.get(position).getName());
        boolean present = false;
        for (ShoppingItem shoppingItem : selectedShoppingItem) {
            if (selectedItem.getName().equalsIgnoreCase(shoppingItem.getName()))
                present = true;
        }

        if (!present)//add item to selected list
            selectedShoppingItem.add(arrayList.get(position));
        detailItemRecyclerViewAdapter.setItems(selectedShoppingItem);
        spinnerDialog = false;

    }

}
